"""
Think of what functions are needed.
"""
