"""
Implements to_networkx and from_networkx interface for GraphicalModel.
"""