"""
Implements to_numpy and from_numpy interface for GraphicalModel.
"""