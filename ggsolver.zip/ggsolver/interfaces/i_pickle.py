"""
Implements to_pickle and from_pickle interface for GraphicalModel.
"""
