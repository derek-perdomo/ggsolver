"""
Implements to_json and from_json interface for GraphicalModel. 
"""