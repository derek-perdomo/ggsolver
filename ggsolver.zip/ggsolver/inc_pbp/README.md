Solver for Incomplete Preferences based Planning. 

