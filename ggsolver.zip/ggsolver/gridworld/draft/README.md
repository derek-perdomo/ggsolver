# Instructions 

The pygame simulation should be run on base OS (not within a docker container).


## GW Orientation

```
   ^
   |                                          N
   |                                        W o E
(2, 0)                                        S
(1, 0)
(0, 0) (0, 1) (0, 2) -->
```

