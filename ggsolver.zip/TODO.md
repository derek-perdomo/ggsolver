# TODO 

- Define Game class, Automaton class, Solver class.
- Implement interface to spot. (`from_spot(spotaut) -> Automaton`).
- Implement DTPTB sub-package with reachability, Buchi games solvers. 
- Add interface to parity game solver (PGSolver). 
- Implement MDP sub-package with qualitative reachability, Buchi game solvers.
- Add interface to mdptoolbox for quantitative solutions.
- Implement POMDP sub-package with qualitative reachability, Buchi (?) game solvers.
- Add interface to some pomdp solver for quantitative solutions.
- ...